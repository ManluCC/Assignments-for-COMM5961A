document.getElementById('get-started-btn').addEventListener('click', sayHello);

    function sayHello(){
      alert("Hello! Welcome to login and explore more! ");
    }


document.getElementById('vr').addEventListener('click', renderVr);

    function renderVr(){
      window.location.href='https://www.ivrpano.com/p/f0def02384d7486d?sid=0&_s=c67097a3237996e9';
    }