from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime

app = Flask(__name__)

db = SQLAlchemy(app)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SECRET_KEY'] = 'asecretkey'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False


class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    username = db.Column(db.String(15), unique=True)
    email = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(80))
    
class Note(db.Model):
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    title = db.Column(db.String(25))
    note_body = db.Column(db.Text)
    note_writer = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    author = db.Column(db.String(255))
    #date_created = db.Column(db.DateTime, nullable=False)
    date_created = db.Column(db.TIMESTAMP, default=datetime.utcnow, nullable=False)      
    

class Venues(db.Model):
    __tablename__ = 'venues'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(50))
    district = db.Column(db.String(25))
    address = db.Column(db.String(150))
    transport = db.Column(db.String(100))
    lng = db.Column(db.Float)
    lat = db.Column(db.Float)    
    img_url = db.Column(db.Text)
    description = db.Column(db.Text)
    style = db.Column(db.String(50))
    
class Photographer(db.Model):
    __tablename__ = 'photographer'
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    name = db.Column(db.String(50))
    url = db.Column(db.Text)
    img_url = db.Column(db.Text)
    fee = db.Column(db.Text)
    time = db.Column(db.Text)
    photographer = db.Column(db.String(50))
    
    
   